var strXMLURL = "xml/videolist.xml";
var videoPlayed = false;
var arrVideoList = new Array();
var curId = 0;
var strCourseName = "";
var vidCurCount = 0;

function doInit() {
    doParseXML(strXMLURL);
}

/*Parsing XML file and Loading info into Array*/
function doParseXML(strFileURL) {
    $.ajax({
        type: "GET",
        url: strFileURL,
        dataType: "xml",
        success: function (xmlDoc) {
            /*Storing and Rendering arrVideoList*/
			strCourseName = "";
			var strId, strSource, strPoster, strLabel;
			$(xmlDoc).find('videoList').each(function () {
				strCourseName = $(this).attr("courseName");
				$(this).find('video').each(function () {
					strId = "";
					strSource = "";
					strPoster = "";
					strLabel = "";
					strId = $(this).attr("id");
					$(this).find('source').each(function () {
						if (strSource == "") {
							strSource = $(this).attr("type") + "~" + $(this).attr("src");
						} else {
							strSource = strSource + "SPLSPLSPL" + $(this).attr("type") + "~" + $(this).attr("src");
						}
					});
					strPoster = $(this).find('poster').attr('src');
					strLabel = $(this).find('label').text();
					arrVideoList.push({ID:strId, SOURCE:strSource, POSTER:strPoster, LABEL:strLabel, VIEWED:""});
				});
			});
		//	document.getElementById('divCourseTitle').innerHTML = "Sample Animation";
			doRenderLeftMenu();
        },
        error: function (xhr, status, error) {
            alert("<b>Error: </b>Error occured while proccessing the XML file. Please check the XML file and try again.");
        }
    });
}

function doRenderLeftMenu() {
	var strLMHtml = '<table width="99.5%" align="center" cellspacing="0" cellpadding="0" border="0">';
	for (i = 0; i < arrVideoList.length; i++) {
		strLMHtml = strLMHtml + '<tr height="30">';
		strLMHtml = strLMHtml + '<td width="100%" align="left" valign="middle">';
		strLMHtml = strLMHtml + '<div id="divMenu_' + arrVideoList[i].ID + '" name="divMenu_' + arrVideoList[i].ID + '"  class="clsMenuNormal" onclick="doPlayVideo(this.id);">';
		strLMHtml = strLMHtml + arrVideoList[i].LABEL;
		strLMHtml = strLMHtml + '</div>';
		strLMHtml = strLMHtml + '</td>';
		strLMHtml = strLMHtml + '</tr>';
	}
	strLMHtml = strLMHtml + '</table>';
	document.getElementById('divLeftMenu').innerHTML = strLMHtml;
	doPlayVideo(arrVideoList[0].ID);
}

function doPlayVideo(strTemp) {
	var strId;
	if (strTemp.indexOf("_")>-1) {
		strId = strTemp.split("_")[1];
	} else {
		strId = strTemp;
	}
    videoPlayed = true;
    var arrSources = new Array();
    var arrTempSplMain;
    var arrTempSplSub;
    var strVideoFileURL = "";
    var strVideoHtml = "";
	for (i = 0; i < arrVideoList.length; i++) {
		if (strId == arrVideoList[i].ID) {
			curId = strId;
			vidCurCount = curId;
			arrVideoList[i].VIEWED = "Yes";
			$("#spanVideoPlayerTitleText").html(arrVideoList[i].LABEL);
			strVideoHtml = strVideoHtml + '<video id="vidPlayer" name="vidPlayer" width="720px" height="550px" poster="' + arrVideoList[i].POSTER + '" controls="controls" preload="auto">';
			arrTempSplMain = arrVideoList[i].SOURCE.split("SPLSPLSPL");
			for (j = 0; j < arrTempSplMain.length; j++) {
				arrTempSplSub = arrTempSplMain[j].split("~");
				arrSources.push({ TYPE: arrTempSplSub[0], SRC: arrTempSplSub[1] });
			}
			break;
		}
	}
	for (i = 0; i < arrSources.length; i++) {
		strVideoHtml = strVideoHtml + '<source type="' + arrSources[i].TYPE + '" src="' + arrSources[i].SRC + '" />';
	}
	strVideoHtml = strVideoHtml + '<object width="720px" height="550px" type="application/x-shockwave-flash" data="mediaelementJS/flashmediaelement.swf">';
	strVideoHtml = strVideoHtml + '<param name="movie" value="mediaelementJS/flashmediaelement.swf" />';
	strVideoHtml = strVideoHtml + '<param name="flashvars" value="controls=true&amp;file=' + arrSources[0].SRC + '" />';
	strVideoHtml = strVideoHtml + '<img src="' + arrVideoList[curId-1].POSTER + '" width="720px" height="550px" alt="Here we are" />';
	strVideoHtml = strVideoHtml + '</object>';
	strVideoHtml = strVideoHtml + '</video>';
	$("#videoSkin").html(strVideoHtml);
	$("#vidPlayer").mediaelementplayer({
		startLanguage: 'en',
		translations: ['es', 'ar', 'zh', 'ru'],
		translationSelector: false
		/*success: function(player, node) {
			player.addEventListener('ended', function(e){
				vidCurCount++;
				if (vidCurCount<arrVideoList.length) {
					doPlayVideo(vidCurCount);
				}
			});
		}*/		
	});
	$("#divVideoPlayer").css("z-index", 1000);
	$("#divVideoPlayer").css("display", "block");
	if (!($.browser.name == "Microsoft Internet Explorer" && $.browser.version == "8"))
		try {
			document.getElementById('vidPlayer').play();
		} catch (e) {
		}
	
	for (i = 0; i < arrVideoList.length; i++) {
		$("#divMenu_" + arrVideoList[i].ID).removeClass('clsMenuSelected').addClass('clsMenuNormal');
	}
	$("#divMenu_" + curId).removeClass('clsMenuNormal').addClass('clsMenuSelected');
}

(function ($) {
    if (jQuery.browser) return;

    jQuery.browser = {};
    jQuery.browser.mozilla = false;
    jQuery.browser.webkit = false;
    jQuery.browser.opera = false;
    jQuery.browser.msie = false;

    var nAgt = navigator.userAgent;
    jQuery.browser.ua = nAgt;

    jQuery.browser.name = navigator.appName;
    jQuery.browser.fullVersion = '' + parseFloat(navigator.appVersion);
    jQuery.browser.majorVersion = parseInt(navigator.appVersion, 10);
    var nameOffset, verOffset, ix;

    // In Opera, the true version is after "Opera" or after "Version"
    if ((verOffset = nAgt.indexOf("Opera")) != -1) {
        jQuery.browser.opera = true;
        jQuery.browser.name = "Opera";
        jQuery.browser.fullVersion = nAgt.substring(verOffset + 6);
        if ((verOffset = nAgt.indexOf("Version")) != -1) jQuery.browser.fullVersion = nAgt.substring(verOffset + 8);
    }

        // In MSIE < 11, the true version is after "MSIE" in userAgent
    else if ((verOffset = nAgt.indexOf("MSIE")) != -1) {
        jQuery.browser.msie = true;
        jQuery.browser.name = "Microsoft Internet Explorer";
        jQuery.browser.fullVersion = nAgt.substring(verOffset + 5);
    }

        // In TRIDENT (IE11) => 11, the true version is after "rv:" in userAgent
    else if (nAgt.indexOf("Trident") != -1) {
        jQuery.browser.msie = true;
        jQuery.browser.name = "Microsoft Internet Explorer";
        var start = nAgt.indexOf("rv:") + 3;
        var end = start + 4;
        jQuery.browser.fullVersion = nAgt.substring(start, end);
    }

        // In Chrome, the true version is after "Chrome"
    else if ((verOffset = nAgt.indexOf("Chrome")) != -1) {
        jQuery.browser.webkit = true;
        jQuery.browser.name = "Chrome";
        jQuery.browser.fullVersion = nAgt.substring(verOffset + 7);
    }
        // In Safari, the true version is after "Safari" or after "Version"
    else if ((verOffset = nAgt.indexOf("Safari")) != -1) {
        jQuery.browser.webkit = true;
        jQuery.browser.name = "Safari";
        jQuery.browser.fullVersion = nAgt.substring(verOffset + 7);
        if ((verOffset = nAgt.indexOf("Version")) != -1) jQuery.browser.fullVersion = nAgt.substring(verOffset + 8);
    }
        // In Safari, the true version is after "Safari" or after "Version"
    else if ((verOffset = nAgt.indexOf("AppleWebkit")) != -1) {
        jQuery.browser.webkit = true;
        jQuery.browser.name = "Safari";
        jQuery.browser.fullVersion = nAgt.substring(verOffset + 7);
        if ((verOffset = nAgt.indexOf("Version")) != -1) jQuery.browser.fullVersion = nAgt.substring(verOffset + 8);
    }
        // In Firefox, the true version is after "Firefox"
    else if ((verOffset = nAgt.indexOf("Firefox")) != -1) {
        jQuery.browser.mozilla = true;
        jQuery.browser.name = "Firefox";
        jQuery.browser.fullVersion = nAgt.substring(verOffset + 8);
    }
        // In most other browsers, "name/version" is at the end of userAgent
    else if ((nameOffset = nAgt.lastIndexOf(' ') + 1) < (verOffset = nAgt.lastIndexOf('/'))) {
        jQuery.browser.name = nAgt.substring(nameOffset, verOffset);
        jQuery.browser.fullVersion = nAgt.substring(verOffset + 1);
        if (jQuery.browser.name.toLowerCase() == jQuery.browser.name.toUpperCase()) {
            jQuery.browser.name = navigator.appName;
        }
    }
    // trim the fullVersion string at semicolon/space if present
    if ((ix = jQuery.browser.fullVersion.indexOf(";")) != -1) jQuery.browser.fullVersion = jQuery.browser.fullVersion.substring(0, ix);
    if ((ix = jQuery.browser.fullVersion.indexOf(" ")) != -1) jQuery.browser.fullVersion = jQuery.browser.fullVersion.substring(0, ix);

    jQuery.browser.majorVersion = parseInt('' + jQuery.browser.fullVersion, 10);
    if (isNaN(jQuery.browser.majorVersion)) {
        jQuery.browser.fullVersion = '' + parseFloat(navigator.appVersion);
        jQuery.browser.majorVersion = parseInt(navigator.appVersion, 10);
    }
    jQuery.browser.version = jQuery.browser.majorVersion;
})(jQuery);